#include <glew.h>
#include <freeglut.h>
#include <SOIL.h>
#include <iostream>
#include <time.h>
#include <vector>
#include <windows.h>
#include <cstdlib>
#include <fmod.hpp>
#include "ShaderLoader.h"

#include "glm.hpp"
#include "gtc/matrix_transform.hpp"
#include "gtc/type_ptr.hpp"
#include "Audio.h"
#include "Input.h"
#include "PlayerManager.h"
#include "Camera.h"
#include "Manager.h"
#include "TextLabel.h"
#include "TextureLoader.h"
#include "CubeMap.h"
#include "Model.h"
#include "ModelMesh.h"

//using namespace
using namespace std;

//reference to shader loader
ShaderLoader m_shader;

//player program
GLuint program = NULL;
//cubeMap Program
GLuint programMap = NULL;


//Player buffers
GLuint VBO;
GLuint VAO;
GLuint EBO;

//delta time stuff
GLfloat currentTime;
GLfloat pasttime = 0;
GLfloat deltaTime;

int fps = 0;
int lives = 3;

//references to other classes
CubeMap cubemap;
LoadTexture lT;
Audio1 audio;
Input input;
camera camMain;
PlayerManager playermanager;
utils utils1;

//player
GLuint player;
GLuint topShape;
GLuint belowTransShape;
GLuint water;

Model model;

//game stuff
float TotalScore = 0.0f;
bool startplay = false;
bool restartplay = true;
int menu = 0;
int gameRound = 1;
float rotO = 0.0f;

glm::vec3 rotationAxisZ = glm::vec3(1.0f, 0.0f, 0.0f);
float rotationAngle = 0;
glm::mat4 rotationZ = glm::rotate(glm::mat4(), glm::radians(rotationAngle), rotationAxisZ);


GLfloat vertices[] //player
{
	-1.0f, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,
	-1.0, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 0.0f,
	1.0, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 0.0f,
	1.0, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,

	-1.0, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	1.0, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,

	1.0, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	1.0, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,

	1.0, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	-1.0, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,

	-1.0, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	-1.0, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,

	0.0f, 0.5f, 0.0f,		0.0f, 1.0f, 1.0f,	0.5f, 0.0f,
};

GLuint indices[] =
{
	1, 4, 3,
	1, 3, 2,

	4, 12, 5,
	6, 12, 7,
	8, 12, 9,
	10, 12, 11,
};

void PlayerRender(float scaleX, float scaleY, float scaleZ, GLuint tex, glm::vec3 position) {

	glUseProgram(program);

	playermanager.movement(audio, deltaTime, utils1.GetSCREEN_W(), utils1.GetSCREEN_H());
	camMain.calculate(currentTime);
	glm::vec3 objPosition = position;
	objPosition += playermanager.GetPlayerPos();
	glm::vec3 objscale = glm::vec3(scaleX, scaleY, scaleZ);

	glm::mat4 mvp = camMain.MVP(objPosition, objscale, rotationZ);
	glm::mat4 model = camMain.Model(objPosition, objscale, rotationZ);
	glm::vec3 camPos = camMain.getPos();

	GLuint mvpLoc = glGetUniformLocation(program, "mvp");
	glUniformMatrix4fv(mvpLoc, 1, GL_FALSE, glm::value_ptr(mvp));

	GLuint modelLoc = glGetUniformLocation(program, "model");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	GLint currentTimeLoc = glGetUniformLocation(program, "currentTime");
	glUniform1f(currentTimeLoc, currentTime);

	glBindVertexArray(VAO);

	glBindTexture(GL_TEXTURE_2D, tex);

	glDrawElements(GL_TRIANGLES, sizeof(indices), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	glUseProgram(0);

}

//manages the render of all objects
void Render()
{

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT |  GL_STENCIL_BUFFER_BIT);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_DEPTH_TEST);

	//enabling the scissor test
	glEnable(GL_SCISSOR_TEST);
	glScissor(0, 100, 1280, 510);
	
	//render the cubemap
	//cubemap.Render();
	
	//if the game has been started
	if (startplay == true)
	{


#pragma region "Transparency Test"

		glm::vec3 tranPos = glm::vec3(0.5f, 0.5f, 0.0f);
		glm::vec3 tranPos2 = glm::vec3(0.5f, 0.3f, 0.0f);

		PlayerRender(0.5f, 0.5f, 1.0f, belowTransShape, tranPos2);
		PlayerRender(0.5f, 0.5f, 1.0f, water, tranPos);


#pragma endregion

#pragma region "Stencil Test"

		glm::vec3 position = glm::vec3(0.5f, 1.5f, 0.0f);

		//enable the stencil test
		glEnable(GL_STENCIL_TEST);
		glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
		glStencilFunc(GL_ALWAYS, 1, 0xFF);
		glStencilMask(0xFF);

		//render the first object
		PlayerRender(0.5f,0.5f,1.0f, player, position);


		glStencilMask(0x00);
		glStencilFunc(GL_NOTEQUAL, 1, 0xFF);

		//render the second object
		PlayerRender(0.6f,0.6f,1.1f, topShape, position);

		//disbale the stencil test
		glDisable(GL_STENCIL_TEST);
		glStencilMask(0xFF);
		glClear(GL_STENCIL_BUFFER_BIT);
#pragma endregion 

	}


	glBindVertexArray(0);
	glUseProgram(0);
	glDisable(GL_SCISSOR_TEST);


	glutSwapBuffers();
}


glm::vec3 camPos = glm::vec3(0.0f, 2.0f, 7.5f);
//update, runs each frame
void Update()
{

	//camera controls
	if (input.CheckKeyDown('w') == true) {
		camPos.x= camPos.x -= deltaTime * deltaTime;
		camMain.setCamPos(camPos);
	}
	if (input.CheckKeyDown('s') == true) {
		camPos.x = camPos.x += deltaTime * deltaTime;
		camMain.setCamPos(camPos);
	}
	if (input.CheckKeyDown('a') == true) {
		camMain.rotate(currentTime);
	}
	if (input.CheckKeyDown('d') == true) {
		camMain.rotate(currentTime);
	}


	//shows that backface culling is working
	if (input.CheckKeyDown('q') == true) {
		glPolygonMode(GL_FRONT, GL_LINE);
	}
	else {
		glPolygonMode(GL_FRONT, GL_FILL);
	}
		if (menu == 0)
		{
			if (input.CheckKeyDown('p') == true)
			{
				gameRound = 1;
				playermanager.initializePlayerPos();
				camPos = glm::vec3(0.0f, 2.0f, 7.5f);
				camMain.setCamPos(glm::vec3((0.0f, 2.0f, 7.5f)));
				startplay = true;
			}
		}


	//update audio
	audio.update();

	currentCamera = &camMain;
	//update the cubemap
	cubemap.Update();
	currentTime = (GLfloat)glutGet(GLUT_ELAPSED_TIME);
	deltaTime = (currentTime - pasttime)* 0.1f;
	pasttime = currentTime;


	glutPostRedisplay();

}

//main loop, entry point
int main(int argc, char **argv)
{
	//set the screen dimensions
	utils1.SetScreenDimentions(1, 1280);
	utils1.SetScreenDimentions(2, 720);
	srand(static_cast <unsigned> (time(0)));
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA | GLUT_STENCIL | GLUT_MULTISAMPLE);
	glutSetOption(GLUT_MULTISAMPLE, 16); glEnable(GL_MULTISAMPLE);
	glutInitWindowPosition(50, 50);

	glutInitWindowSize(static_cast<int>(utils1.GetSCREEN_W()), static_cast<int>(utils1.GetSCREEN_H()));
	glutCreateWindow("Advanced Open GL Program Thing");
	
	if (glewInit() != GLEW_OK)
	{
		cout << "Uhhh, boss we'z got a probl'm" << endl;
		system("pause");
	}

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glFrontFace(GL_CCW);

	//set the camera to projection
	camMain.SetProj(glm::perspective(45.0f, (float)utils1.GetSCREEN_W() / (float)utils1.GetSCREEN_H(), 0.1f, 10000.0f));

	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

	//create the programs
	program = ShaderLoader::CreateProgram("Assets/shader/Fog.vs", "Assets/shader/Fog.fs");
	programMap = ShaderLoader::CreateProgram("CubeMap.vs", "CubeMap.fs");

	
	//set the cubemap program
	cubemap.setProgram(programMap);

	//create cubemap, using the folder named yokahama
	cubemap.Create("yokahama");

	//create the player
#pragma region "player"

	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);

	glGenBuffers(1, &EBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

	glGenBuffers(1, &VBO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, (8 * (sizeof(GLfloat))), (GLvoid*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, (8 * (sizeof(GLfloat))), (GLvoid*)(3 * (sizeof(GLfloat))));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, (8 * (sizeof(GLfloat))), (GLvoid*)(6 * (sizeof(GLfloat))));
	glEnableVertexAttribArray(2);

	glActiveTexture(GL_TEXTURE0);
	player = lT.loadTexture("Assets/Textures/spaceShips_009.png");
	topShape = lT.loadTexture("Assets/Textures/RedPng.png");
	belowTransShape = lT.loadTexture("Assets/Textures/spaceBuilding_007.png");
	water = lT.loadTexture("Assets/Textures/Water.png");
	glBindTexture(GL_TEXTURE_2D, player);
	glUniform1i(glGetUniformLocation(program, "tex"), 0);


#pragma endregion 

	//init camera
	camMain.initCamera();

	//init the audio and load some sounds
	//audio.AudioInit();
	//audio.Create("Assets/sounds/WhoTaughtYouHowToHate.mp3", 1);
	//audio.Create("Assets/Sounds/Thump.wav", 2);
	//play the background track
	//audio.playSound(1);

	//create the model
	//model = Model::Model("Assets/models/pug/dog 1.obj", &camMain);

	//setup
	glutDisplayFunc(Render);
	glutIdleFunc(Update);

	glutKeyboardFunc(Input::KeyboardDown);
	glutKeyboardUpFunc(Input::KeyboardUp);

	glutMainLoop();

	return 0;
}