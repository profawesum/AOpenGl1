#include "Camera.h"
#include "glm.hpp"
#include <iostream>
#include <freeglut.h>

using namespace glm;

camera::camera()
{
}

camera::~camera()
{
}
//init the camera
void camera::initCamera(){
	camPos = glm::vec3(0.0f, 2.0f, 7.5f);
	camLookDir = glm::vec3(0.0f, 0.0f, -1.0f);
	camUpDir = glm::vec3(0.0f, 1.0f, 0.0f);
}

//calculate the view of the camera
void camera::calculate(GLfloat currentTime){

	camTar = glm::vec3(0.0f, 0.0f, 0.0f);
	view = glm::lookAt(camPos, camTar, camUpDir);

}
//get the model matrix
glm::mat4 camera::Model(glm::vec3 postion, glm::vec3 scale, glm::mat4 rotationZ)
{

	vec3 backObjPosition = postion;
	mat4 backTranslationMatrix = glm::translate(glm::mat4(), backObjPosition);
	vec3 objscaleBack = scale;
	mat4 scaleMatrixBack = glm::scale(glm::mat4(), objscaleBack);
	mat4 backModel = backTranslationMatrix * rotationZ * scaleMatrixBack;

	return(backModel);
}
//return the view of the camera
glm::mat4 camera::getView()
{
	return (view);
}
//return the projection of the camera
glm::mat4 camera::getProj()
{
	return (proj);
}
glm::vec3 camera::getPos()
{
	return(camPos);
}
//calculate the mvp matrix
glm::mat4 camera::MVP(glm::vec3 postion, glm::vec3 scale, glm::mat4 rotationZ)
{
	vec3 backObjPosition = postion;
	mat4 backTranslationMatrix = glm::translate(glm::mat4(), backObjPosition);
	vec3 objscaleBack = scale;
	mat4 scaleMatrixBack = glm::scale(glm::mat4(), objscaleBack);
	mat4 backModel = backTranslationMatrix * rotationZ * scaleMatrixBack;
	mat4 backProj_calc = proj * getView() * backModel;
	return (backProj_calc);
}
//set the projection of the camera
glm::mat4 camera::SetProj(glm::mat4 project)
{
	proj = project;
	return glm::mat4();
}

glm::vec3 camera::setCamPos(glm::vec3 pos)
{
	camPos.z = pos.x;
	return pos;
}

void camera::rotate(GLfloat currentTime)
{
	rotMat2 = glm::rotate(glm::mat4(), glm::radians(0.01f * currentTime), glm::vec3(0, 1, 0));
	rotMat = glm::rotate(glm::mat4(), glm::radians(-30.0f), glm::vec3(1, 0, 0));

	newPos = rotMat * glm::vec4(-3, 2, 3, 1) * rotMat2;
	camPos = glm::vec3(newPos);

}

camera* currentCamera = nullptr;

