#pragma once

#include <freeglut.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include "glm.hpp"
#include "gtc/matrix_transform.hpp"
#include "gtc/type_ptr.hpp"
#include "Audio.h"
#include "Input.h"


class PlayerManager
{
public:

	PlayerManager();
	~PlayerManager();
	glm::vec3 GetPlayerPos();
	void SetPlayerPos(glm::vec3);
	void initializePlayerPos();
	void movement(Audio1& audio2, GLfloat deltaTime, float ScreenW, float screenH);

private:
	glm::vec3 playerPos;
};